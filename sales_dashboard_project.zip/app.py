
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="Sales Dashboard", layout="wide")

st.title("📊 Sales Data Analysis Dashboard")

uploaded_file = st.file_uploader("Upload sales.csv file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)
    df['Date'] = pd.to_datetime(df['Date'])

    st.subheader("📋 Dataset Preview")
    st.dataframe(df.head())

    total_sales = df['Sales'].sum()
    total_quantity = df['Quantity'].sum()
    unique_products = df['Product'].nunique()

    col1, col2, col3 = st.columns(3)
    col1.metric("💰 Total Sales", f"₹{total_sales:,.0f}")
    col2.metric("📦 Total Quantity", f"{total_quantity}")
    col3.metric("🛍️ Unique Products", unique_products)

    st.subheader("🛒 Sales by Product")
    product_sales = df.groupby('Product')['Sales'].sum().sort_values(ascending=False)
    fig1, ax1 = plt.subplots()
    sns.barplot(x=product_sales.index, y=product_sales.values, palette="Blues_r", ax=ax1)
    ax1.set_ylabel("Sales (₹)")
    ax1.set_xlabel("Product")
    ax1.set_title("Sales by Product")
    st.pyplot(fig1)

    st.subheader("🌍 Sales by Region")
    region_sales = df.groupby('Region')['Sales'].sum()
    fig2, ax2 = plt.subplots()
    region_sales.plot(kind='pie', autopct='%1.1f%%', startangle=90, ax=ax2)
    ax2.set_ylabel("")
    ax2.set_title("Sales Distribution by Region")
    st.pyplot(fig2)

    st.subheader("📅 Daily Sales Trend")
    daily_sales = df.groupby('Date')['Sales'].sum()
    fig3, ax3 = plt.subplots()
    daily_sales.plot(ax=ax3, marker='o')
    ax3.set_title("Daily Sales")
    ax3.set_xlabel("Date")
    ax3.set_ylabel("Sales (₹)")
    st.pyplot(fig3)

    st.subheader("⬇️ Download Processed Data")
    csv = df.to_csv(index=False).encode('utf-8')
    st.download_button("Download Clean CSV", csv, "clean_sales.csv", "text/csv")
else:
    st.info("Please upload a sales.csv file to get started.")
